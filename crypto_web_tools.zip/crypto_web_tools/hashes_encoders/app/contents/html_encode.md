---
title: HTML Encode
template: page.jade
js: https://rawgit.com/emn178/js-htmlencode/master/build/htmlencode.min.js
method: htmlEncode
action: Encode
auto_update: true
description: HTML online encode function
keywords: HTML,online,encode
---
