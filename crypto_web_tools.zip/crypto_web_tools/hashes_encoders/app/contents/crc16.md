---
title: CRC-16
template: page.jade
js: https://rawgit.com/emn178/js-crc/master/build/crc.min.js
method: crc16
action: Hash
auto_update: true
description: CRC-16 online hash function
keywords: CRC,CRC-16,online,hash
---
