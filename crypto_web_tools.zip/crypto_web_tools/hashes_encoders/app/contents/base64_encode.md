---
title: Base64 Encode
template: page.jade
js: https://rawgit.com/emn178/hi-base64/master/build/base64.min.js
method: base64.encode
action: Encode
auto_update: true
description: Base64 online encode function
keywords: Base64,online,encode
---
