---
title: HTML Decode
template: page.jade
js: https://rawgit.com/emn178/js-htmlencode/master/build/htmlencode.min.js
method: htmlDecode
action: Decode
auto_update: true
description: HTML online decode function
keywords: HTML,online,decode
---
