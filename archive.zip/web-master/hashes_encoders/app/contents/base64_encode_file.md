---
title: Base64 Encode File
template: page.jade
js: https://rawgit.com/emn178/hi-base64/master/build/base64.min.js
method: base64.encode
action: Encode
auto_update: true
file_input: true
description: Base64 online encode file function
keywords: Base64,online,encode,file
---
