---
title: SHA1 File Checksum
template: page.jade
js: https://rawgit.com/emn178/js-sha1/master/build/sha1.min.js
method: sha1
action: Hash
auto_update: true
file_input: true
description: SHA1 online hash file checksum function
keywords: SHA1,online,hash,checksum
---
