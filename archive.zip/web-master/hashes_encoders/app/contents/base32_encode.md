---
title: Base32 Encode
template: page.jade
js: https://rawgit.com/emn178/hi-base32/master/build/base32.min.js
method: base32.encode
action: Encode
auto_update: true
description: Base32 online encode function
keywords: Base32,online,encode
---
