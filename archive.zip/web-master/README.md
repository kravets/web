# web
Some immutable web resources, load 
http://hawaiki.org/
https://kravets.github.io/web/
